create definer = miki@localhost trigger generate_codebar
    before insert
    on products
    for each row
BEGIN
    SET NEW.codebar = CONCAT(
            NEW.id,
            IF(NEW.favorite IS NULL, '0', NEW.favorite),
            NEW.brand,
            NEW.quantity,
            NEW.storage,
            DATE_FORMAT(NEW.created_at, '%Y%m%d%H%i%s')
        );
END;


create definer = miki@localhost trigger generate_codebar
    before insert
    on products
    for each row
BEGIN
    SET NEW.codebar = CONCAT(NEW.id, NEW.brand, NEW.category, NEW.created_at, NEW.storage);
END;


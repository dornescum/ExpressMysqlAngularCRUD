create
    definer = miki@localhost procedure GetProductsByUID(IN user_id int)
BEGIN
    SELECT * FROM products WHERE uid = user_id;
END;

